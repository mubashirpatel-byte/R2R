import { useState, useEffect, useRef, useCallback } from "react";

/* ─────────────────────────────────────────────────────────
   SCROLL REVEAL HOOK
───────────────────────────────────────────────────────── */
function useReveal() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { el.classList.add("visible"); obs.disconnect(); } },
      { threshold: 0.12 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  return ref;
}

function useCountUp(target: number, duration = 1600) {
  const [val, setVal] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const started = useRef(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting && !started.current) {
        started.current = true;
        const t0 = performance.now();
        const tick = (now: number) => {
          const p = Math.min((now - t0) / duration, 1);
          const eased = 1 - Math.pow(1 - p, 4);
          setVal(Math.round(eased * target));
          if (p < 1) requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
      }
    }, { threshold: 0.4 });
    obs.observe(el);
    return () => obs.disconnect();
  }, [target, duration]);
  return { val, ref };
}

/* ─────────────────────────────────────────────────────────
   ICONS
───────────────────────────────────────────────────────── */
const I = {
  Pin: (p: { s?: number; c?: string }) => (
    <svg width={p.s??20} height={p.s??20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={p.c}>
      <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/>
    </svg>),
  Camera: (p: { s?: number; c?: string }) => (
    <svg width={p.s??20} height={p.s??20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={p.c}>
      <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/>
    </svg>),
  Check: (p: { s?: number; c?: string }) => (
    <svg width={p.s??20} height={p.s??20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className={p.c}>
      <polyline points="20 6 9 17 4 12"/>
    </svg>),
  Shield: (p: { s?: number; c?: string }) => (
    <svg width={p.s??20} height={p.s??20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={p.c}>
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
    </svg>),
  Bell: (p: { s?: number; c?: string }) => (
    <svg width={p.s??20} height={p.s??20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={p.c}>
      <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>
    </svg>),
  Users: (p: { s?: number; c?: string }) => (
    <svg width={p.s??20} height={p.s??20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={p.c}>
      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/>
      <path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>
    </svg>),
  Zap: (p: { s?: number; c?: string }) => (
    <svg width={p.s??20} height={p.s??20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={p.c}>
      <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>
    </svg>),
  Chart: (p: { s?: number; c?: string }) => (
    <svg width={p.s??20} height={p.s??20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={p.c}>
      <line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/>
      <line x1="6" y1="20" x2="6" y2="14"/><line x1="2" y1="20" x2="22" y2="20"/>
    </svg>),
  Upload: (p: { s?: number; c?: string }) => (
    <svg width={p.s??20} height={p.s??20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={p.c}>
      <polyline points="16 16 12 12 8 16"/><line x1="12" y1="12" x2="12" y2="21"/>
      <path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3"/>
    </svg>),
  Cpu: (p: { s?: number; c?: string }) => (
    <svg width={p.s??20} height={p.s??20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={p.c}>
      <rect x="4" y="4" width="16" height="16" rx="2"/><rect x="9" y="9" width="6" height="6"/>
      <line x1="9" y1="1" x2="9" y2="4"/><line x1="15" y1="1" x2="15" y2="4"/>
      <line x1="9" y1="20" x2="9" y2="23"/><line x1="15" y1="20" x2="15" y2="23"/>
      <line x1="20" y1="9" x2="23" y2="9"/><line x1="20" y1="14" x2="23" y2="14"/>
      <line x1="1" y1="9" x2="4" y2="9"/><line x1="1" y1="14" x2="4" y2="14"/>
    </svg>),
  Menu: (p: { s?: number; c?: string }) => (
    <svg width={p.s??20} height={p.s??20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={p.c}>
      <line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/>
    </svg>),
  Close: (p: { s?: number; c?: string }) => (
    <svg width={p.s??20} height={p.s??20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={p.c}>
      <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
    </svg>),
  Arrow: (p: { s?: number; c?: string }) => (
    <svg width={p.s??20} height={p.s??20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={p.c}>
      <line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/>
    </svg>),
  Award: (p: { s?: number; c?: string }) => (
    <svg width={p.s??20} height={p.s??20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={p.c}>
      <circle cx="12" cy="8" r="6"/><path d="M15.477 12.89 17 22l-5-3-5 3 1.523-9.11"/>
    </svg>),
  Star: (p: { s?: number; c?: string; filled?: boolean }) => (
    <svg width={p.s??14} height={p.s??14} viewBox="0 0 24 24" fill={p.filled?"currentColor":"none"} stroke="currentColor" strokeWidth="2" className={p.c}>
      <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
    </svg>),
  Globe: (p: { s?: number; c?: string }) => (
    <svg width={p.s??20} height={p.s??20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={p.c}>
      <circle cx="12" cy="12" r="10"/>
      <line x1="2" y1="12" x2="22" y2="12"/>
      <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>
    </svg>),
};

/* ─────────────────────────────────────────────────────────
   NAVIGATION
───────────────────────────────────────────────────────── */
function Nav({ onReport }: { onReport: () => void }) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", fn, { passive: true });
    return () => window.removeEventListener("scroll", fn);
  }, []);

  const links = [
    { label: "How It Works", href: "#how" },
    { label: "Live Map", href: "#map" },
    { label: "Features", href: "#features" },
    { label: "Accountability", href: "#accountability" },
  ];

  return (
    <nav className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${scrolled ? "nav-scrolled" : "nav-top"}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Logo */}
        <a href="#" className="flex items-center gap-2.5">
          <div className="w-8 h-8 grad-blue rounded-[10px] flex items-center justify-center shadow-blue" style={{boxShadow:"0 2px 10px rgba(26,86,219,0.45)"}}>
            <I.Pin s={15} c="text-white" />
          </div>
          <span className={`font-extrabold text-[17px] tracking-tight leading-none ${scrolled ? "text-slate-900" : "text-white"}`}>
            Road<span className={scrolled ? "text-[#1a56db]" : "text-emerald-400"}>Rakshak</span>
          </span>
          <span className={`mono text-[9px] font-bold px-1.5 py-0.5 rounded-md border ${scrolled ? "border-blue-200 text-blue-700 bg-blue-50" : "border-white/20 text-white/70 bg-white/10"}`}>BETA</span>
        </a>

        {/* Desktop nav */}
        <div className="hidden md:flex items-center gap-1">
          {links.map(l => (
            <a key={l.href} href={l.href}
              className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all ${scrolled ? "text-slate-600 hover:text-slate-900 hover:bg-slate-50" : "text-white/75 hover:text-white hover:bg-white/10"}`}>
              {l.label}
            </a>
          ))}
        </div>

        {/* Desktop CTA */}
        <div className="hidden md:flex items-center gap-3">
          <span className={`text-sm font-semibold cursor-pointer transition-colors ${scrolled ? "text-slate-600 hover:text-blue-700" : "text-white/80 hover:text-white"}`}>
            Sign In
          </span>
          <button onClick={onReport} className="btn btn-blue" style={{padding:"10px 20px",fontSize:"13px",borderRadius:"12px"}}>
            <I.Camera s={15} />
            Report Now
          </button>
        </div>

        {/* Mobile toggle */}
        <button onClick={() => setMobileOpen(o => !o)}
          className={`md:hidden p-2 rounded-xl transition-colors ${scrolled ? "text-slate-700 hover:bg-slate-100" : "text-white hover:bg-white/10"}`}>
          {mobileOpen ? <I.Close s={20} /> : <I.Menu s={20} />}
        </button>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="md:hidden mx-3 mb-2 glass rounded-2xl shadow-lift overflow-hidden">
          <div className="p-3 flex flex-col gap-1">
            {links.map(l => (
              <a key={l.href} href={l.href} onClick={() => setMobileOpen(false)}
                className="px-4 py-3 rounded-xl text-sm font-semibold text-slate-700 hover:bg-slate-50 transition-colors">
                {l.label}
              </a>
            ))}
          </div>
          <div className="p-3 pt-0">
            <button onClick={() => { onReport(); setMobileOpen(false); }} className="btn btn-blue w-full">
              <I.Camera s={16} /> Report a Pothole
            </button>
          </div>
        </div>
      )}
    </nav>
  );
}

/* ─────────────────────────────────────────────────────────
   PHONE MOCKUP
───────────────────────────────────────────────────────── */
function PhoneMockup() {
  const [step, setStep] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setStep(s => (s + 1) % 3), 3000);
    return () => clearInterval(t);
  }, []);

  const screens = [
    /* Screen 0 — capture */
    <div key="capture" className="h-full flex flex-col">
      <div className="h-10 grad-blue flex items-center justify-between px-4 pt-1">
        <span className="mono text-white text-[10px] font-semibold">9:41</span>
        <span className="text-white text-[10px]">●●●</span>
      </div>
      <div className="grad-blue px-4 pb-4">
        <p className="text-white/60 text-[9px] font-medium">Good morning, Priya 🙏</p>
        <p className="text-white font-bold text-[13px]">Report a Pothole</p>
      </div>
      <div className="flex-1 bg-slate-50 p-3 space-y-2.5">
        <div className="relative h-32 bg-slate-800 rounded-2xl overflow-hidden">
          <img src="https://images.unsplash.com/photo-1520594923568-1b5d82587f86?w=400&h=200&fit=crop&auto=format"
            alt="Road aerial" className="w-full h-full object-cover opacity-70"/>
          <div className="absolute inset-0 bg-gradient-to-t from-slate-900/70 to-transparent"/>
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-1">
            <div className="w-11 h-11 rounded-full border-2 border-white flex items-center justify-center">
              <div className="w-8 h-8 rounded-full bg-white/25"/>
            </div>
            <span className="text-white text-[9px] font-semibold">Tap to Capture</span>
          </div>
          <div className="absolute top-2 right-2 bg-emerald-500 text-white text-[8px] font-bold px-2 py-0.5 rounded-full">AI LIVE</div>
        </div>
        <div className="bg-white rounded-xl p-2.5 flex items-center gap-2 border border-slate-100">
          <div className="w-6 h-6 bg-blue-50 rounded-lg flex items-center justify-center flex-shrink-0">
            <I.Pin s={12} c="text-blue-600" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-[8px] text-slate-400 font-medium">AUTO-DETECTED</p>
            <p className="text-[10px] font-bold text-slate-900 truncate">MG Road, Ward 12, Pune</p>
          </div>
          <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse flex-shrink-0"/>
        </div>
        <button className="w-full grad-blue text-white text-[10px] font-bold py-2.5 rounded-xl">Submit Report →</button>
      </div>
    </div>,

    /* Screen 1 — AI analyzing */
    <div key="ai" className="h-full flex flex-col">
      <div className="h-10 grad-blue flex items-center justify-between px-4 pt-1">
        <span className="mono text-white text-[10px] font-semibold">9:41</span>
        <span className="text-white text-[10px]">●●●</span>
      </div>
      <div className="grad-blue px-4 pb-4">
        <p className="text-white/60 text-[9px] font-medium">AI Analysis in progress…</p>
        <p className="text-white font-bold text-[13px]">Processing Photo</p>
      </div>
      <div className="flex-1 bg-slate-50 p-3 flex flex-col gap-2.5">
        <div className="bg-white rounded-2xl p-3 border border-slate-100">
          <p className="text-[9px] font-bold text-slate-700 mb-2">AI Confidence Score</p>
          <div className="flex justify-between mb-1.5">
            <span className="text-[8px] text-slate-500">Pothole Detected</span>
            <span className="mono text-[9px] font-bold text-blue-700">94%</span>
          </div>
          <div className="prog-track mb-2"><div className="prog-fill" style={{width:"94%"}}/></div>
          <div className="flex justify-between mb-1.5">
            <span className="text-[8px] text-slate-500">Severity</span>
            <span className="mono text-[9px] font-bold text-red-600">HIGH</span>
          </div>
          <div className="prog-track mb-2"><div className="prog-fill" style={{width:"80%",background:"linear-gradient(90deg,#ef4444,#dc2626)"}}/></div>
          <div className="flex items-center gap-1.5 mt-2 p-1.5 bg-amber-50 rounded-lg border border-amber-100">
            <span className="text-[8px] text-amber-700 font-medium">⚠ 1 duplicate found 38m away — merging</span>
          </div>
        </div>
        <div className="bg-white rounded-2xl p-3 border border-slate-100">
          <p className="text-[9px] font-bold text-slate-700 mb-2">Routing to Authority</p>
          {[
            {l:"Municipality",v:"PMC Pune"},
            {l:"Ward",v:"Ward 12"},
            {l:"Engineer",v:"Anil Sharma"},
          ].map(r=>(
            <div key={r.l} className="flex justify-between py-1 border-b border-slate-50 last:border-0">
              <span className="text-[8px] text-slate-400">{r.l}</span>
              <span className="text-[8px] font-bold text-slate-900">{r.v}</span>
            </div>
          ))}
        </div>
      </div>
    </div>,

    /* Screen 2 — success */
    <div key="success" className="h-full flex flex-col items-center justify-center bg-white p-5 gap-3">
      <div className="w-16 h-16 grad-emerald rounded-full flex items-center justify-center shadow-emerald pop-in">
        <I.Check s={30} c="text-white" />
      </div>
      <p className="font-extrabold text-slate-900 text-[14px] text-center">Report Submitted!</p>
      <p className="text-slate-400 text-[9px] text-center">Routed to PMC Ward 12, Pune</p>
      <div className="w-full bg-slate-50 rounded-xl p-2.5 border border-slate-100">
        <p className="mono text-[8px] text-slate-400 mb-0.5">COMPLAINT ID</p>
        <p className="mono text-[11px] font-bold text-blue-700">RR-2024-PNE-48721</p>
      </div>
      <div className="badge-verified text-[9px]">
        <I.Shield s={10} /> Municipal Verified
      </div>
    </div>,
  ];

  return (
    <div className="relative flex justify-center">
      {/* Glow behind phone */}
      <div className="absolute inset-0 scale-[0.7] blur-3xl" style={{background:"radial-gradient(ellipse, rgba(26,86,219,0.4) 0%, rgba(5,150,105,0.2) 60%, transparent 80%)"}}/>

      <div className="phone-frame w-[260px]">
        <div className="phone-screen bg-slate-50" style={{height:"480px"}}>
          {screens[step]}
        </div>

        {/* Step dots */}
        <div className="flex justify-center gap-1.5 mt-3 mb-1">
          {screens.map((_, i) => (
            <button key={i} onClick={() => setStep(i)}
              className={`rounded-full transition-all ${i === step ? "w-5 h-1.5 bg-blue-400" : "w-1.5 h-1.5 bg-white/30"}`}/>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────
   HERO
───────────────────────────────────────────────────────── */
function Hero({ onReport, onTrack }: { onReport: () => void; onTrack: () => void }) {
  return (
    <section className="relative min-h-screen flex items-center overflow-hidden">
      {/* BG image */}
      <div className="absolute inset-0 bg-slate-900">
        <img src="https://images.unsplash.com/photo-1520594923568-1b5d82587f86?w=1600&h=900&fit=crop&auto=format"
          alt="Aerial view of Indian roads" className="w-full h-full object-cover mix-blend-luminosity opacity-40"/>
        <div className="grad-hero absolute inset-0"/>
      </div>

      {/* Dot grid */}
      <div className="absolute inset-0 opacity-[0.07]"
        style={{backgroundImage:"radial-gradient(circle, rgba(255,255,255,0.9) 1px, transparent 1px)", backgroundSize:"36px 36px"}}/>

      {/* Floating map pins */}
      {[
        {x:"12%",y:"28%",color:"pin-r",delay:"0s",dur:"3.2s"},
        {x:"28%",y:"55%",color:"pin-y",delay:"0.7s",dur:"4s"},
        {x:"72%",y:"35%",color:"pin-g",delay:"1.2s",dur:"3.6s"},
        {x:"85%",y:"65%",color:"pin-r",delay:"0.4s",dur:"3.8s"},
      ].map((pin, i) => (
        <div key={i} className="absolute" style={{left:pin.x, top:pin.y}}>
          <div className={`pin w-3.5 h-3.5 ${pin.color}`}
            style={{animation:`bounce ${pin.dur} ${pin.delay} ease-in-out infinite`, position:"static", transform:"none"}}>
            <div className={`pulse-ring w-3.5 h-3.5 ${pin.color} opacity-50`} style={{animationDelay:pin.delay}}/>
          </div>
        </div>
      ))}

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-16 w-full">
        <div className="grid lg:grid-cols-[1fr_auto] gap-12 xl:gap-20 items-center">
          {/* Copy */}
          <div className="max-w-2xl">
            {/* Gov badge */}
            <div className="inline-flex items-center gap-2.5 glass-white-sm rounded-full px-4 py-2 mb-8">
              <div className="flag-bar w-10 rounded-sm overflow-hidden" style={{height:"5px"}}>
                <div/><div/><div/>
              </div>
              <span className="text-white/85 text-[11px] font-semibold tracking-wide">
                Ministry of Road Transport & Highways · Govt. of India
              </span>
            </div>

            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-extrabold text-white leading-[1.04] tracking-[-0.02em] mb-6">
              One Photo.<br/>
              One Report.<br/>
              <span style={{background:"linear-gradient(90deg,#34d399,#059669)", WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent"}}>
                Safer Roads.
              </span>
            </h1>

            <p className="body-text text-white/65 text-xl leading-relaxed mb-8 max-w-lg">
              AI-powered pothole detection routes your complaint to the right Municipal Corporation automatically—and tracks the repair to completion.
            </p>

            {/* Quick stats */}
            <div className="flex gap-8 mb-10">
              {[
                {n:"2.4L+", l:"Reports"},
                {n:"89K+",  l:"Repaired"},
                {n:"247",   l:"Cities"},
              ].map(s => (
                <div key={s.l}>
                  <p className="stat-num text-3xl font-extrabold text-white">{s.n}</p>
                  <p className="text-white/50 text-xs font-medium mt-0.5">{s.l}</p>
                </div>
              ))}
            </div>

            <div className="flex flex-wrap gap-3">
              <button onClick={onReport} className="btn btn-blue btn-lg">
                <I.Camera s={18}/> Report a Pothole
              </button>
              <button onClick={onTrack} className="btn btn-ghost btn-lg">
                <I.Pin s={18}/> Track Complaint
              </button>
            </div>

            {/* Trust chips */}
            <div className="flex flex-wrap gap-2 mt-8">
              {["ISO 27001 Certified","DigiLocker Ready","Aadhaar Verified","CERT-In Secured"].map(t => (
                <span key={t} className="glass-white-sm text-white/70 text-[11px] font-medium px-3 py-1.5 rounded-full flex items-center gap-1.5">
                  <I.Check s={10} c="text-emerald-400"/> {t}
                </span>
              ))}
            </div>
          </div>

          {/* Phone */}
          <div className="hidden lg:block">
            <PhoneMockup/>
          </div>
        </div>
      </div>

      {/* Scroll cue */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1.5">
        <span className="mono text-white/30 text-[9px] tracking-widest">SCROLL</span>
        <div className="w-px h-10 bg-gradient-to-b from-white/30 to-transparent"/>
      </div>
    </section>
  );
}

/* ─────────────────────────────────────────────────────────
   LIVE IMPACT
───────────────────────────────────────────────────────── */
function StatCard({icon, label, val, unit, sub, accent}: {
  icon: React.ReactNode; label: string; val: number; unit: string; sub: string; accent: string;
}) {
  const { val: count, ref } = useCountUp(val);
  const revealRef = useReveal();

  return (
    <div ref={revealRef} className="reveal card shadow-card card-hover p-6">
      <div className={`w-12 h-12 ${accent} rounded-2xl flex items-center justify-center mb-5`}>{icon}</div>
      <div className="stat-num text-4xl font-extrabold text-slate-900 mb-1">
        <span ref={ref}>{count.toLocaleString("en-IN")}</span>{unit}
      </div>
      <div className="font-semibold text-slate-700 text-sm mb-1">{label}</div>
      <div className="body-text text-slate-400 text-xs">{sub}</div>
    </div>
  );
}

function LiveImpact() {
  const titleRef = useReveal();

  return (
    <section className="py-24 grad-mesh" id="impact">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div ref={titleRef} className="reveal text-center mb-14">
          <p className="sect-label mb-3">Live Impact</p>
          <h2 className="text-4xl sm:text-5xl font-extrabold text-slate-900 tracking-tight mb-4">
            India's roads are changing—<br className="hidden sm:block"/>
            <span style={{color:"#1a56db"}}>right now</span>
          </h2>
          <p className="body-text text-slate-500 text-lg max-w-md mx-auto">
            Every report triggers a real government work order. These numbers update daily.
          </p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          <StatCard icon={<I.Upload s={22} c="text-blue-600"/>} label="Reports Submitted" val={247318} unit="+" sub="This financial year" accent="bg-blue-50"/>
          <StatCard icon={<I.Check s={22} c="text-emerald-600"/>} label="Roads Repaired" val={89124} unit="+" sub="Verified with photos" accent="bg-emerald-50"/>
          <StatCard icon={<I.Zap s={22} c="text-amber-600"/>} label="Avg. Resolution" val={11} unit=" days" sub="Down from 34 days in 2022" accent="bg-amber-50"/>
          <StatCard icon={<I.Globe s={22} c="text-violet-600"/>} label="Municipalities" val={247} unit="" sub="Active civic partners" accent="bg-violet-50"/>
        </div>

        {/* Live ticker */}
        <div className="mt-8 glass rounded-2xl px-5 py-3.5 flex items-center gap-4 overflow-hidden">
          <div className="flex items-center gap-2 flex-shrink-0">
            <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"/>
            <span className="mono text-emerald-600 text-[10px] font-bold tracking-wider">LIVE</span>
          </div>
          <div className="body-text text-sm text-slate-600 font-medium whitespace-nowrap overflow-hidden" style={{maskImage:"linear-gradient(90deg,transparent,#000 5%,#000 95%,transparent)"}}>
            2 min ago: Pothole repaired on Anna Salai, Chennai &nbsp;·&nbsp; 5 min ago: New report verified in Bandra, Mumbai &nbsp;·&nbsp; 11 min ago: Ward 23 Bengaluru completed 8 repairs &nbsp;·&nbsp; 18 min ago: Road sealed on NH-48 near Gurugram
          </div>
        </div>
      </div>
    </section>
  );
}

/* ─────────────────────────────────────────────────────────
   HOW IT WORKS
───────────────────────────────────────────────────────── */
function HowItWorks() {
  const titleRef = useReveal();
  const [active, setActive] = useState(0);

  const steps = [
    {
      n: "01",
      title: "Snap & Submit",
      summary: "Upload Photo",
      desc: "Open RoadRakshak, take a photo, and hit submit. GPS metadata is captured automatically—no manual address entry needed. The whole process takes under 30 seconds.",
      icon: <I.Camera s={28} c="text-blue-600"/>,
      bg: "bg-blue-50",
      detail: [
        "GPS coordinates captured from EXIF data",
        "Timestamp recorded for legal validity",
        "Photo compressed & encrypted in transit",
        "Works offline—queues until signal returns",
      ],
      img: "https://images.unsplash.com/photo-1753127096071-55bebb47d9f2?w=600&h=400&fit=crop&auto=format",
      accent: "#1a56db",
    },
    {
      n: "02",
      title: "AI Routes Instantly",
      summary: "AI Analysis",
      desc: "Our computer vision model measures pothole depth, area, and risk level. Duplicate detection scans a 50m radius. The complaint is routed to the exact responsible municipal ward—no human handoff.",
      icon: <I.Cpu s={28} c="text-amber-600"/>,
      bg: "bg-amber-50",
      detail: [
        "99.2% pothole detection accuracy",
        "Depth & area estimated via monocular depth AI",
        "Duplicate merge within 50m radius",
        "Auto-routes to legally responsible ward officer",
      ],
      img: "https://images.unsplash.com/photo-1780314501317-80b578aee4e8?w=600&h=400&fit=crop&auto=format",
      accent: "#d97706",
    },
    {
      n: "03",
      title: "Repair & Verify",
      summary: "Track & Close",
      desc: "Engineers receive a prioritized work order on their municipal dashboard. You get push notifications at each stage. Completion requires a geo-tagged photo from the repair crew.",
      icon: <I.Shield s={28} c="text-emerald-600"/>,
      bg: "bg-emerald-50",
      detail: [
        "Geo-tagged after photo required to close",
        "Citizen can rate the quality of repair",
        "SLA breach triggers automatic escalation",
        "Public record preserved permanently",
      ],
      img: "https://images.unsplash.com/photo-1515256722043-0f2b082ddadc?w=600&h=400&fit=crop&auto=format",
      accent: "#059669",
    },
  ];

  return (
    <section className="py-24 bg-white" id="how">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div ref={titleRef} className="reveal text-center mb-16">
          <p className="sect-label mb-3">Process</p>
          <h2 className="text-4xl sm:text-5xl font-extrabold text-slate-900 tracking-tight mb-4">
            Three steps to safer roads
          </h2>
          <p className="body-text text-slate-500 text-lg max-w-lg mx-auto">
            From photo to repaired road in under 14 days—powered by AI and enforced by government accountability.
          </p>
        </div>

        {/* Step selector */}
        <div className="flex flex-col sm:flex-row gap-2 justify-center mb-12">
          {steps.map((s, i) => (
            <button key={i} onClick={() => setActive(i)}
              className={`flex items-center gap-3 px-5 py-3.5 rounded-2xl font-semibold text-sm transition-all border ${
                active === i
                  ? "shadow-lift border-transparent text-white"
                  : "bg-white border-slate-200 text-slate-600 hover:border-slate-300"
              }`}
              style={active === i ? {background:`linear-gradient(135deg,${s.accent},${s.accent}cc)`, borderColor:"transparent"} : {}}>
              <span className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-extrabold ${active === i ? "bg-white/20 text-white" : s.bg}`}
                style={active !== i ? {color:s.accent} : {}}>
                {s.n}
              </span>
              {s.summary}
            </button>
          ))}
        </div>

        {/* Detail panel */}
        <div className="grid lg:grid-cols-2 gap-10 items-center">
          <div>
            <div className={`w-16 h-16 ${steps[active].bg} rounded-3xl flex items-center justify-center mb-6`}>
              {steps[active].icon}
            </div>
            <h3 className="text-3xl font-extrabold text-slate-900 mb-4">{steps[active].title}</h3>
            <p className="body-text text-slate-500 text-lg leading-relaxed mb-8">{steps[active].desc}</p>
            <div className="space-y-3">
              {steps[active].detail.map((d, i) => (
                <div key={i} className="flex items-start gap-3">
                  <div className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5"
                    style={{background:steps[active].accent}}>
                    <I.Check s={11} c="text-white"/>
                  </div>
                  <span className="body-text text-slate-700 text-sm leading-relaxed">{d}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="relative rounded-3xl overflow-hidden h-80 lg:h-96 bg-slate-200">
            <img src={steps[active].img} alt={steps[active].title} className="w-full h-full object-cover transition-all duration-500"/>
            <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 to-transparent"/>
            <div className="absolute bottom-4 left-4">
              <span className="glass-navy text-white text-xs font-bold px-3 py-1.5 rounded-full">
                Step {active + 1} of 3
              </span>
            </div>
          </div>
        </div>

        {/* Metrics strip */}
        <div className="mt-16 grid grid-cols-3 gap-4">
          {[
            {v:"< 30s", l:"Average submission time", c:"text-blue-700", bg:"bg-blue-50", b:"border-blue-100"},
            {v:"99.2%", l:"AI detection accuracy", c:"text-amber-700", bg:"bg-amber-50", b:"border-amber-100"},
            {v:"Zero",  l:"Duplicate complaints processed", c:"text-emerald-700", bg:"bg-emerald-50", b:"border-emerald-100"},
          ].map(m => (
            <div key={m.l} className={`${m.bg} border ${m.b} rounded-2xl p-4 sm:p-5 text-center`}>
              <div className={`mono text-2xl sm:text-3xl font-extrabold ${m.c} mb-1`}>{m.v}</div>
              <div className="body-text text-slate-500 text-xs sm:text-sm">{m.l}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─────────────────────────────────────────────────────────
   INTERACTIVE MAP
───────────────────────────────────────────────────────── */
const PINS_DATA = [
  {id:1, x:"21%", y:"33%", s:"reported", title:"MG Road Pothole", ward:"Ward 12, Pune", time:"2h ago", sev:"High", upvotes:14},
  {id:2, x:"45%", y:"54%", s:"progress", title:"Station Rd Crack", ward:"Ward 7, Pune", time:"1d ago", sev:"Medium", upvotes:8},
  {id:3, x:"67%", y:"27%", s:"resolved", title:"NH-48 Surface Damage", ward:"Ward 3, Pune", time:"3d ago", sev:"Critical", upvotes:31},
  {id:4, x:"34%", y:"72%", s:"reported", title:"Market St. Pothole", ward:"Ward 18, Pune", time:"4h ago", sev:"Low", upvotes:3},
  {id:5, x:"76%", y:"61%", s:"progress", title:"Ring Road Patch", ward:"Ward 22, Pune", time:"2d ago", sev:"High", upvotes:19},
  {id:6, x:"54%", y:"42%", s:"resolved", title:"Civil Lines Repair", ward:"Ward 5, Pune", time:"5d ago", sev:"Medium", upvotes:22},
  {id:7, x:"14%", y:"62%", s:"reported", title:"Camp Area Pothole", ward:"Ward 9, Pune", time:"30m ago", sev:"High", upvotes:6},
];

function InteractiveMap() {
  const [active, setActive] = useState<typeof PINS_DATA[0] | null>(null);
  const [filter, setFilter] = useState<"all"|"reported"|"progress"|"resolved">("all");
  const titleRef = useReveal();

  const visible = PINS_DATA.filter(p => filter === "all" || p.s === filter);
  const pinClass = (s: string) => s==="reported"?"pin-r":s==="progress"?"pin-y":"pin-g";
  const statusLabel = (s: string) => s==="reported"?"Reported":s==="progress"?"In Progress":"Resolved";
  const statusColor = (s: string) => s==="reported"?"bg-red-100 text-red-700":s==="progress"?"bg-amber-100 text-amber-700":"bg-emerald-100 text-emerald-700";

  return (
    <section className="py-24 bg-slate-50" id="map">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div ref={titleRef} className="reveal text-center mb-12">
          <p className="sect-label mb-3">Live Map</p>
          <h2 className="text-4xl sm:text-5xl font-extrabold text-slate-900 tracking-tight mb-4">
            Real-time pothole heatmap
          </h2>
          <p className="body-text text-slate-500 text-lg max-w-md mx-auto">
            Every pin represents a citizen's report. Colors show accountability in action.
          </p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-2 justify-center mb-6">
          {[
            {k:"all",l:"All Reports",bg:"bg-slate-900 text-white",off:"bg-white text-slate-700 border border-slate-200"},
            {k:"reported",l:"🔴 Reported",bg:"bg-red-600 text-white",off:"bg-white text-red-700 border border-red-200"},
            {k:"progress",l:"🟡 In Progress",bg:"bg-amber-500 text-white",off:"bg-white text-amber-700 border border-amber-200"},
            {k:"resolved",l:"🟢 Resolved",bg:"bg-emerald-600 text-white",off:"bg-white text-emerald-700 border border-emerald-200"},
          ].map(f => (
            <button key={f.k} onClick={() => { setFilter(f.k as typeof filter); setActive(null); }}
              className={`px-4 py-2 rounded-xl font-semibold text-sm transition-all ${filter===f.k ? f.bg : f.off+" hover:shadow-sm"}`}>
              {f.l}
            </button>
          ))}
        </div>

        {/* Map container */}
        <div className="card shadow-lift overflow-hidden">
          {/* Map viewport */}
          <div className="relative map-bg" style={{height:"480px"}}>
            {/* Roads */}
            <div className="absolute top-1/2 inset-x-0 bg-white/70" style={{height:"16px",transform:"translateY(-50%)"}}/>
            <div className="absolute inset-y-0 left-1/2 bg-white/70" style={{width:"12px",transform:"translateX(-50%)"}}/>
            <div className="absolute bg-white/50" style={{top:"28%",left:"5%",right:"15%",height:"10px",transform:"rotate(8deg)"}}/>
            <div className="absolute bg-white/50" style={{top:"68%",left:"8%",right:"25%",height:"8px",transform:"rotate(-5deg)"}}/>
            <div className="absolute bg-white/40" style={{top:"45%",left:"55%",right:"5%",height:"8px",transform:"rotate(12deg)"}}/>

            {/* Heatmap blobs */}
            <div className="heatblob absolute w-56 h-56 bg-red-400/25" style={{left:"8%",top:"18%",animationDuration:"8s"}}/>
            <div className="heatblob absolute w-36 h-36 bg-amber-400/20" style={{left:"58%",top:"42%",animationDuration:"10s",animationDelay:"2s"}}/>
            <div className="heatblob absolute w-44 h-44 bg-emerald-400/18" style={{left:"62%",top:"18%",animationDuration:"9s",animationDelay:"4s"}}/>

            {/* Pins */}
            {visible.map(pin => (
              <div key={pin.id}>
                {/* Pulse ring */}
                {pin.s === "reported" && (
                  <div className={`pin pulse-ring w-4 h-4 ${pinClass(pin.s)} opacity-40`}
                    style={{left:pin.x,top:pin.y,animationDelay:`${pin.id*0.4}s`}}/>
                )}
                <div onClick={() => setActive(active?.id===pin.id ? null : pin)}
                  className={`pin w-4 h-4 ${pinClass(pin.s)}`}
                  style={{left:pin.x,top:pin.y}}/>
              </div>
            ))}

            {/* Map controls */}
            <div className="absolute top-3 right-3 flex flex-col gap-1">
              {["+","−"].map(c => (
                <button key={c} className="w-9 h-9 bg-white rounded-xl shadow text-slate-700 font-bold text-lg flex items-center justify-center hover:bg-slate-50 transition-colors">
                  {c}
                </button>
              ))}
            </div>

            {/* Legend */}
            <div className="absolute bottom-3 left-3 glass rounded-2xl px-3.5 py-2.5">
              {[
                {c:"bg-red-500",l:"Reported"},
                {c:"bg-amber-500",l:"In Progress"},
                {c:"bg-emerald-500",l:"Resolved"},
              ].map(l => (
                <div key={l.l} className="flex items-center gap-2 py-0.5">
                  <div className={`w-2.5 h-2.5 rounded-full ${l.c}`}/>
                  <span className="text-[10px] text-slate-700 font-medium">{l.l}</span>
                </div>
              ))}
            </div>

            {/* Attribution */}
            <div className="absolute bottom-3 right-3 mono text-[9px] text-slate-400">
              Map · RoadRakshak GIS © 2024
            </div>

            {/* Active popup */}
            {active && (
              <div className="slide-up absolute glass rounded-2xl p-4 w-60 shadow-float z-20"
                style={{left:`calc(${active.x} + 16px)`, top:`calc(${active.y} - 16px)`, maxWidth:"calc(100% - 32px)"}}>
                <div className="flex justify-between items-start mb-2">
                  <span className="font-bold text-slate-900 text-sm leading-tight">{active.title}</span>
                  <button onClick={() => setActive(null)} className="text-slate-400 hover:text-slate-700 ml-2 flex-shrink-0">
                    <I.Close s={14}/>
                  </button>
                </div>
                <div className="flex items-center gap-2 mb-2">
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${statusColor(active.s)}`}>
                    {statusLabel(active.s)}
                  </span>
                  <span className="mono text-[9px] text-slate-400">{active.time}</span>
                </div>
                <p className="text-xs text-slate-500 mb-2">{active.ward} · Severity: <strong className="text-slate-800">{active.sev}</strong></p>
                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-slate-400">👍 {active.upvotes} upvotes</span>
                  <button className="text-[11px] font-bold text-blue-700 hover:text-blue-900 transition-colors">
                    View Report →
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Bottom strip */}
          <div className="p-4 border-t border-slate-100 flex gap-3 overflow-x-auto bg-white">
            {PINS_DATA.slice(0,5).map(p => (
              <button key={p.id} onClick={() => { setFilter("all"); setActive(p); }}
                className={`flex-shrink-0 p-3 rounded-xl text-left transition-all w-44 border ${active?.id===p.id ? "border-blue-300 bg-blue-50" : "border-slate-100 hover:border-slate-200 hover:bg-slate-50"}`}>
                <p className="text-xs font-bold text-slate-900 truncate mb-0.5">{p.title}</p>
                <p className="text-[10px] text-slate-400 mb-1.5">{p.ward}</p>
                <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${statusColor(p.s)}`}>
                  {statusLabel(p.s)}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

/* ─────────────────────────────────────────────────────────
   REPORT INTERFACE
───────────────────────────────────────────────────────── */
function ReportInterface() {
  const [drag, setDrag] = useState(false);
  const [uploaded, setUploaded] = useState(false);
  const [aiProgress, setAiProgress] = useState(0);
  const [severity, setSeverity] = useState("high");
  const [desc, setDesc] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const titleRef = useReveal();

  const triggerUpload = useCallback(() => {
    setUploaded(true);
    let p = 0;
    const iv = setInterval(() => {
      p += 7;
      setAiProgress(Math.min(p, 94));
      if (p >= 94) clearInterval(iv);
    }, 60);
  }, []);

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault(); setDrag(false); triggerUpload();
  };

  const reset = () => {
    setUploaded(false); setAiProgress(0); setSeverity("high"); setDesc(""); setSubmitted(false);
  };

  const sevOpts = [
    {k:"low",l:"Low",on:"bg-slate-700 text-white",off:"bg-slate-50 text-slate-600 border border-slate-200"},
    {k:"medium",l:"Medium",on:"bg-amber-500 text-white",off:"bg-amber-50 text-amber-700 border border-amber-200"},
    {k:"high",l:"High",on:"bg-red-600 text-white",off:"bg-red-50 text-red-700 border border-red-200"},
    {k:"critical",l:"Critical",on:"bg-red-900 text-white",off:"bg-red-50 text-red-900 border border-red-300"},
  ];

  return (
    <section className="py-24 bg-white" id="report">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-[1.1fr_1fr] gap-14 items-center">
          {/* Left */}
          <div>
            <div ref={titleRef} className="reveal">
              <p className="sect-label mb-3">Report Interface</p>
              <h2 className="text-4xl sm:text-5xl font-extrabold text-slate-900 tracking-tight mb-5">
                File a report in<br/><span style={{color:"#1a56db"}}>under 30 seconds</span>
              </h2>
              <p className="body-text text-slate-500 text-lg leading-relaxed mb-10">
                We handle routing, deduplication, and AI severity scoring. You just take the photo.
              </p>
            </div>
            <div className="space-y-4">
              {[
                {icon:<I.Cpu s={18} c="text-blue-600"/>, bg:"bg-blue-50", t:"AI Severity Detection", d:"Pothole depth and area estimated by monocular depth AI in under 2 seconds."},
                {icon:<I.Pin s={18} c="text-emerald-600"/>, bg:"bg-emerald-50", t:"Precise GPS Auto-Detection", d:"EXIF coordinates extracted—no manual address entry, ever."},
                {icon:<I.Shield s={18} c="text-amber-600"/>, bg:"bg-amber-50", t:"50m Duplicate Prevention", d:"Identical reports within 50m are merged, not duplicated, saving civic resources."},
                {icon:<I.Bell s={18} c="text-violet-600"/>, bg:"bg-violet-50", t:"Real-time Status Updates", d:"Push notifications at every stage from submission to sealed road."},
              ].map(item => (
                <div key={item.t} className="flex gap-4 p-4 rounded-2xl bg-slate-50 border border-slate-100 hover:border-slate-200 transition-all">
                  <div className={`w-10 h-10 ${item.bg} rounded-xl flex items-center justify-center flex-shrink-0`}>
                    {item.icon}
                  </div>
                  <div>
                    <p className="font-bold text-slate-900 text-sm mb-0.5">{item.t}</p>
                    <p className="body-text text-slate-500 text-xs leading-relaxed">{item.d}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right: form */}
          <div>
            {submitted ? (
              <div className="card shadow-float p-10 flex flex-col items-center text-center">
                <div className="w-24 h-24 grad-emerald rounded-full flex items-center justify-center mb-6 pop-in" style={{boxShadow:"0 16px 48px rgba(5,150,105,0.4)"}}>
                  <I.Check s={40} c="text-white"/>
                </div>
                <h3 className="text-2xl font-extrabold text-slate-900 mb-2">Report Submitted!</h3>
                <p className="body-text text-slate-500 text-sm mb-6">Routed to PMC Ward 12 · Assigned to Eng. Anil Sharma</p>
                <div className="w-full bg-slate-50 rounded-2xl p-5 mb-5 border border-slate-100">
                  <p className="mono text-[10px] text-slate-400 mb-1">COMPLAINT ID</p>
                  <p className="mono text-2xl font-bold text-blue-700">RR-2024-PNE-48721</p>
                </div>
                <div className="badge-verified mb-6">
                  <I.Shield s={12}/> PMC Pune · Municipal Verified
                </div>
                <button onClick={reset} className="btn btn-outline w-full">Report Another</button>
              </div>
            ) : (
              <div className="card shadow-lift p-6">
                <div className="flex items-center justify-between mb-5">
                  <h3 className="font-extrabold text-slate-900">New Pothole Report</h3>
                  <span className="badge-verified" style={{background:"linear-gradient(135deg,#1a56db,#1338a8)"}}>
                    <I.Shield s={11}/> Secure
                  </span>
                </div>

                {/* Drop zone */}
                <div className={`drop-zone p-7 text-center mb-5 ${drag ? "drag-active":""}`}
                  onDragOver={e=>{e.preventDefault();setDrag(true);}}
                  onDragLeave={()=>setDrag(false)}
                  onDrop={handleDrop}>
                  {uploaded ? (
                    <div className="space-y-3">
                      <div className="w-12 h-12 grad-blue rounded-full mx-auto flex items-center justify-center pop-in">
                        <I.Check s={22} c="text-white"/>
                      </div>
                      <p className="font-bold text-slate-800 text-sm">Photo uploaded — AI analyzing…</p>
                      <div className="prog-track mx-auto" style={{maxWidth:"200px"}}>
                        <div className="prog-fill" style={{width:`${aiProgress}%`}}/>
                      </div>
                      {aiProgress >= 94 && (
                        <div className="flex items-center justify-center gap-1.5 text-emerald-600">
                          <I.Check s={12}/>
                          <span className="text-xs font-bold">94% confidence — HIGH severity pothole detected</span>
                        </div>
                      )}
                    </div>
                  ) : (
                    <>
                      <div className="w-12 h-12 bg-slate-100 rounded-2xl mx-auto flex items-center justify-center mb-3">
                        <I.Upload s={22} c="text-slate-400"/>
                      </div>
                      <p className="font-semibold text-slate-700 text-sm mb-1">Drag & drop photo or{" "}
                        <button className="text-blue-600 hover:underline font-bold" onClick={triggerUpload}>browse</button>
                      </p>
                      <p className="body-text text-slate-400 text-xs">JPG, PNG, HEIC · Max 20 MB · GPS metadata preserved</p>
                    </>
                  )}
                </div>

                {/* GPS row */}
                <div className="flex items-center gap-3 p-3 bg-emerald-50 rounded-xl border border-emerald-100 mb-4">
                  <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse flex-shrink-0"/>
                  <div>
                    <p className="mono text-[9px] text-emerald-600 font-bold tracking-wider">GPS AUTO-DETECTED</p>
                    <p className="font-bold text-slate-900 text-sm">12.9716°N, 77.5946°E · Ward 12, Bengaluru</p>
                  </div>
                </div>

                {/* Severity */}
                <div className="mb-4">
                  <p className="text-xs font-bold text-slate-700 mb-2">Severity Level</p>
                  <div className="flex gap-1.5">
                    {sevOpts.map(s => (
                      <button key={s.k} onClick={()=>setSeverity(s.k)}
                        className={`sev-pill flex-1 ${severity===s.k ? s.on : s.off}`}>
                        {s.l}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Description */}
                <textarea value={desc} onChange={e=>setDesc(e.target.value)}
                  placeholder="Describe pothole—nearby landmark, vehicle damage, time you noticed it…"
                  className="body-text w-full border border-slate-200 rounded-xl px-4 py-3 text-sm text-slate-700 placeholder:text-slate-400 resize-none h-20 mb-4 focus:outline-none focus:ring-2 focus:ring-blue-300 focus:border-blue-400 transition-all"/>

                {/* Duplicate warning */}
                <div className="flex items-start gap-2.5 bg-amber-50 border border-amber-200 rounded-xl p-3 mb-5">
                  <span className="text-amber-500 text-base flex-shrink-0">⚠</span>
                  <p className="body-text text-xs text-amber-800 leading-relaxed">
                    <strong>1 similar report found 38m away.</strong> Your submission will be merged with RR-2024-BLR-48700, boosting its priority queue position.
                  </p>
                </div>

                <button onClick={() => setSubmitted(true)} className="btn btn-blue w-full btn-lg">
                  <I.Arrow s={17}/> Submit to Municipal Corporation
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}

/* ─────────────────────────────────────────────────────────
   TRACK DASHBOARD
───────────────────────────────────────────────────────── */
function TrackDashboard() {
  const [query, setQuery] = useState("");
  const [visible, setVisible] = useState(true);
  const titleRef = useReveal();

  const stages = [
    {s:"Reported",         d:"12 Dec 2024, 09:14 AM", done:true,  icon:<I.Camera s={14} c="text-white"/>},
    {s:"AI Verified",      d:"12 Dec 2024, 09:15 AM", done:true,  icon:<I.Cpu s={14} c="text-white"/>},
    {s:"Assigned to AE",   d:"13 Dec 2024, 11:30 AM", done:true,  icon:<I.Shield s={14} c="text-white"/>},
    {s:"Repair In Progress",d:"18 Dec 2024, 08:00 AM",done:true,  icon:<I.Zap s={14} c="text-white"/>},
    {s:"Completed",        d:"Estimated: 22 Dec 2024", done:false, icon:<I.Check s={14} c="text-white"/>},
  ];
  const doneCount = stages.filter(s=>s.done).length;
  const pct = Math.round(doneCount / stages.length * 100);

  return (
    <section className="py-24 grad-mesh" id="track">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div ref={titleRef} className="reveal text-center mb-12">
          <p className="sect-label mb-3">Track Complaint</p>
          <h2 className="text-4xl sm:text-5xl font-extrabold text-slate-900 tracking-tight mb-4">
            Full transparency, every step
          </h2>
          <p className="body-text text-slate-500 text-lg max-w-lg mx-auto">
            Enter your complaint ID to see live repair status, ward contact, and photographic proof of fix.
          </p>
        </div>

        {/* Search */}
        <div className="max-w-lg mx-auto mb-10">
          <div className="card shadow-card p-2 flex gap-2">
            <input value={query} onChange={e=>setQuery(e.target.value)}
              placeholder="e.g. RR-2024-PNE-48721"
              className="mono flex-1 px-4 py-2.5 text-sm focus:outline-none bg-transparent text-slate-800 placeholder:text-slate-400 placeholder:font-sans"/>
            <button onClick={()=>setVisible(true)} className="btn btn-blue" style={{padding:"10px 20px",fontSize:"13px",borderRadius:"12px"}}>
              Track
            </button>
          </div>
        </div>

        {visible && (
          <div className="grid lg:grid-cols-[1.5fr_1fr] gap-6">
            {/* Main timeline card */}
            <div className="card shadow-lift p-6">
              <div className="flex flex-wrap items-start justify-between gap-4 mb-6 pb-6 border-b border-slate-100">
                <div>
                  <p className="mono text-[10px] text-slate-400 mb-1">COMPLAINT ID</p>
                  <p className="mono text-2xl font-extrabold text-blue-700 mb-1">RR-2024-PNE-48721</p>
                  <p className="body-text text-sm text-slate-500">MG Road pothole, near State Bank ATM, Ward 12, Pune</p>
                </div>
                <div className="badge-verified">
                  <I.Shield s={12}/> PMC Verified
                </div>
              </div>

              {/* Progress */}
              <div className="mb-8">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-bold text-slate-700">Repair Progress</span>
                  <span className="mono font-extrabold text-blue-700">{pct}%</span>
                </div>
                <div className="prog-track">
                  <div className="prog-fill" style={{width:`${pct}%`}}/>
                </div>
              </div>

              {/* Timeline */}
              <div className="relative">
                <div className="absolute left-5 top-5 bottom-5 w-0.5 timeline-spine opacity-25"/>
                <div className="space-y-6">
                  {stages.map((st, i) => (
                    <div key={i} className="relative flex gap-5 items-start">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center z-10 flex-shrink-0 ${
                        st.done ? "grad-blue" : i === doneCount ? "grad-amber animate-pulse" : "bg-slate-100"
                      }`}>
                        {st.done ? st.icon : i === doneCount
                          ? <div className="w-2.5 h-2.5 bg-white rounded-full"/>
                          : <div className="w-2.5 h-2.5 bg-slate-300 rounded-full"/>}
                      </div>
                      <div className={`flex-1 pt-1.5 ${i > doneCount ? "opacity-35" : ""}`}>
                        <p className="font-bold text-slate-900 text-sm">{st.s}</p>
                        <p className="mono text-[10px] text-slate-400 mt-0.5">{st.done ? st.d : "Pending"}</p>
                      </div>
                      {st.done && i === doneCount - 1 && (
                        <span className="text-[10px] bg-blue-50 text-blue-700 font-bold px-2 py-0.5 rounded-full mt-1.5 flex-shrink-0">CURRENT</span>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Side panel */}
            <div className="flex flex-col gap-4">
              {/* Ward details */}
              <div className="card shadow-card p-5">
                <p className="font-bold text-slate-900 mb-4 text-sm">Ward Details</p>
                {[
                  {l:"Municipality", v:"PMC, Pune"},
                  {l:"Ward", v:"Ward 12 — Shivajinagar"},
                  {l:"Asst. Engineer", v:"Anil Sharma"},
                  {l:"Contact", v:"+91-20-2612-5566"},
                  {l:"Est. Completion", v:"22 Dec 2024"},
                  {l:"SLA Deadline", v:"26 Dec 2024"},
                ].map(r => (
                  <div key={r.l} className="flex justify-between items-center py-2.5 border-b border-slate-50 last:border-0">
                    <span className="body-text text-xs text-slate-500">{r.l}</span>
                    <span className="text-xs font-bold text-slate-900 text-right">{r.v}</span>
                  </div>
                ))}
              </div>

              {/* Before/After */}
              <div className="card shadow-card p-5">
                <p className="font-bold text-slate-900 mb-3 text-sm">Before / After Photos</p>
                <div className="grid grid-cols-2 gap-2">
                  <div className="relative rounded-2xl overflow-hidden h-28 bg-slate-200">
                    <img src="https://images.unsplash.com/photo-1515256722043-0f2b082ddadc?w=200&h=140&fit=crop&auto=format"
                      alt="Road before repair" className="w-full h-full object-cover"/>
                    <div className="absolute bottom-2 left-2 bg-red-600 text-white text-[8px] font-extrabold px-2 py-0.5 rounded-md">BEFORE</div>
                  </div>
                  <div className="relative rounded-2xl overflow-hidden h-28 bg-slate-100 flex flex-col items-center justify-center gap-2">
                    <div className="w-8 h-8 bg-slate-200 rounded-full flex items-center justify-center">
                      <I.Camera s={14} c="text-slate-400"/>
                    </div>
                    <p className="text-[9px] text-slate-400 font-medium text-center">After photo<br/>pending</p>
                    <div className="absolute bottom-2 left-2 bg-slate-400 text-white text-[8px] font-extrabold px-2 py-0.5 rounded-md">AFTER</div>
                  </div>
                </div>
              </div>

              {/* Rate quality */}
              <div className="card shadow-card p-5">
                <p className="font-bold text-slate-900 mb-3 text-sm">Rate Repair Quality</p>
                <div className="flex gap-1 mb-3">
                  {[1,2,3,4,5].map(n => (
                    <button key={n} className="text-slate-200 hover:text-amber-400 transition-colors">
                      <I.Star s={24} filled/>
                    </button>
                  ))}
                </div>
                <p className="body-text text-xs text-slate-400">Your rating helps improve contractor accountability.</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}

/* ─────────────────────────────────────────────────────────
   FEATURES
───────────────────────────────────────────────────────── */
function Features() {
  const [activeTab, setActiveTab] = useState(0);
  const titleRef = useReveal();

  const tabs = [
    {label:"AI & Detection", icon:<I.Cpu s={16}/>},
    {label:"Routing & Maps", icon:<I.Pin s={16}/>},
    {label:"Community", icon:<I.Users s={16}/>},
    {label:"Accountability", icon:<I.Chart s={16}/>},
  ];

  const featureGroups = [
    [
      {icon:<I.Cpu s={24} c="text-blue-600"/>, bg:"bg-blue-50", t:"AI Pothole Detection", d:"Computer vision identifies potholes with 99.2% accuracy—measuring depth, width, and surface area in under 2 seconds using a MobileNet-derived model."},
      {icon:<I.Shield s={24} c="text-slate-600"/>, bg:"bg-slate-50", t:"Duplicate Prevention", d:"Within a 50m geofence, submitted reports are merged with existing complaints rather than creating noise. Saves 60% of civic processing overhead."},
      {icon:<I.Zap s={24} c="text-amber-600"/>, bg:"bg-amber-50", t:"Smart Priority Queue", d:"AI ranks potholes by traffic volume, proximity to schools & hospitals, accident history, and monsoon risk—so engineers fix what matters most first."},
    ],
    [
      {icon:<I.Pin s={24} c="text-emerald-600"/>, bg:"bg-emerald-50", t:"GPS Smart Routing", d:"Precise coordinate tagging auto-identifies the legally responsible ward. No manual selection, no misrouting across civic boundaries."},
      {icon:<I.Globe s={24} c="text-blue-600"/>, bg:"bg-blue-50", t:"Live Heatmap", d:"Real-time city-wide pothole density map with Red/Yellow/Green status pins. Public view requires no login—radical transparency by design."},
      {icon:<I.Bell s={24} c="text-violet-600"/>, bg:"bg-violet-50", t:"Push Notifications", d:"Citizens receive alerts at every status change. Engineers get escalation pings when SLA deadlines approach. All via WhatsApp, SMS, or app notification."},
    ],
    [
      {icon:<I.Users s={24} c="text-rose-600"/>, bg:"bg-rose-50", t:"Community Upvoting", d:"Citizens can upvote existing reports to boost their priority ranking—turning crowd behavior into democratic civic pressure."},
      {icon:<I.Star s={24} c="text-amber-600"/>, bg:"bg-amber-50", t:"Repair Quality Rating", d:"After a pothole is marked resolved, citizens rate repair quality on 5 stars. Low ratings trigger a re-inspection within 48 hours."},
      {icon:<I.Camera s={24} c="text-slate-600"/>, bg:"bg-slate-50", t:"Photographic Closure", d:"Contractors must submit a geo-tagged before/after photo to close a complaint. No photo, no closure—period."},
    ],
    [
      {icon:<I.Chart s={24} c="text-blue-600"/>, bg:"bg-blue-50", t:"Ward Leaderboards", d:"Monthly public rankings of every Municipal Corporation by resolution speed, SLA adherence, and citizen satisfaction score."},
      {icon:<I.Award s={24} c="text-amber-600"/>, bg:"bg-amber-50", t:"RoadScore™ Index", d:"Proprietary composite score combining resolution time, recurrence rate, and citizen ratings into a single accountability metric."},
      {icon:<I.Shield s={24} c="text-emerald-600"/>, bg:"bg-emerald-50", t:"RTI-Ready Records", d:"All complaint data is permanently archived and exportable under RTI. Citizens can access any report they filed at any time."},
    ],
  ];

  return (
    <section className="py-24 bg-white" id="features">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div ref={titleRef} className="reveal text-center mb-14">
          <p className="sect-label mb-3">Capabilities</p>
          <h2 className="text-4xl sm:text-5xl font-extrabold text-slate-900 tracking-tight mb-4">
            Built for accountability at scale
          </h2>
          <p className="body-text text-slate-500 text-lg max-w-lg mx-auto">
            Twelve features that transform how cities maintain roads—and how citizens demand results.
          </p>
        </div>

        {/* Tabs */}
        <div className="flex flex-wrap gap-2 justify-center mb-10 p-1.5 bg-slate-100 rounded-2xl max-w-fit mx-auto">
          {tabs.map((t, i) => (
            <button key={i} onClick={() => setActiveTab(i)}
              className={`tab-btn flex items-center gap-2 ${activeTab===i ? "tab-active" : "tab-inactive"}`}>
              {t.icon} {t.label}
            </button>
          ))}
        </div>

        {/* Feature grid */}
        <div className="grid sm:grid-cols-3 gap-5">
          {featureGroups[activeTab].map((f, i) => (
            <div key={i} className="card shadow-card card-hover p-6">
              <div className={`w-12 h-12 ${f.bg} rounded-2xl flex items-center justify-center mb-5`}>
                {f.icon}
              </div>
              <h3 className="font-extrabold text-slate-900 mb-2">{f.t}</h3>
              <p className="body-text text-slate-500 text-sm leading-relaxed">{f.d}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─────────────────────────────────────────────────────────
   ACCOUNTABILITY
───────────────────────────────────────────────────────── */
const LB = [
  {rank:1,city:"Pune",mc:"PMC",res:12847,avg:"8.2d",score:97,trend:"+3%",up:true},
  {rank:2,city:"Ahmedabad",mc:"AMC",res:11203,avg:"9.1d",score:94,trend:"+1%",up:true},
  {rank:3,city:"Hyderabad",mc:"GHMC",res:10981,avg:"10.4d",score:91,trend:"+5%",up:true},
  {rank:4,city:"Bengaluru",mc:"BBMP",res:9782,avg:"11.0d",score:88,trend:"−2%",up:false},
  {rank:5,city:"Chennai",mc:"GCC",res:8456,avg:"12.3d",score:84,trend:"+2%",up:true},
  {rank:6,city:"Mumbai",mc:"BMC",res:7934,avg:"13.8d",score:79,trend:"0%",up:false},
  {rank:7,city:"Jaipur",mc:"JMC",res:6219,avg:"14.1d",score:74,trend:"+4%",up:true},
];

const RECENT_DONE = [
  {id:"RR-48700",loc:"Residency Rd, Bengaluru",days:9,date:"21 Dec",stars:4.8},
  {id:"RR-48234",loc:"FC Road, Pune",days:6,date:"20 Dec",stars:5.0},
  {id:"RR-47891",loc:"Hitech City, Hyderabad",days:11,date:"19 Dec",stars:4.6},
  {id:"RR-47503",loc:"Anna Nagar, Chennai",days:8,date:"18 Dec",stars:4.9},
  {id:"RR-47102",loc:"Sector 15, Chandigarh",days:7,date:"17 Dec",stars:4.7},
];

function Accountability() {
  const titleRef = useReveal();
  return (
    <section className="py-24 bg-slate-50" id="accountability">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div ref={titleRef} className="reveal text-center mb-14">
          <p className="sect-label mb-3">Accountability</p>
          <h2 className="text-4xl sm:text-5xl font-extrabold text-slate-900 tracking-tight mb-4">
            Ward-wise performance rankings
          </h2>
          <p className="body-text text-slate-500 text-lg max-w-md mx-auto">
            Public rankings hold every Municipal Corporation accountable. Updated daily.
          </p>
        </div>

        <div className="grid lg:grid-cols-[1.8fr_1fr] gap-6">
          {/* Leaderboard */}
          <div className="card shadow-lift overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-white">
              <p className="font-extrabold text-slate-900">Municipality Rankings · Dec 2024</p>
              <div className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"/>
                <span className="mono text-[10px] text-slate-400">Live</span>
              </div>
            </div>

            {/* Header row */}
            <div className="px-6 py-2 bg-slate-50 border-b border-slate-100 grid items-center text-[10px] mono text-slate-400 font-semibold tracking-wider"
              style={{gridTemplateColumns:"40px 1fr 90px 60px 100px 40px"}}>
              <span>#</span><span>CITY</span><span className="text-right">RESOLVED</span>
              <span className="text-right hidden sm:block">AVG</span>
              <span className="text-center">SCORE</span><span className="text-right">TREND</span>
            </div>

            <div className="divide-y divide-slate-50 bg-white">
              {LB.map(r => (
                <div key={r.rank} className="lb-row px-6 py-3.5 grid items-center"
                  style={{gridTemplateColumns:"40px 1fr 90px 60px 100px 40px"}}>
                  <div className={`w-7 h-7 rounded-lg flex items-center justify-center font-extrabold text-xs ${
                    r.rank===1?"grad-blue text-white":r.rank===2?"bg-slate-200 text-slate-700":r.rank===3?"grad-amber text-white":"bg-slate-50 text-slate-400"
                  }`}>{r.rank}</div>
                  <div>
                    <p className="font-bold text-slate-900 text-sm">{r.city}</p>
                    <p className="mono text-[10px] text-slate-400">{r.mc}</p>
                  </div>
                  <p className="mono text-sm font-bold text-slate-900 text-right">{r.res.toLocaleString("en-IN")}</p>
                  <p className="mono text-sm text-slate-500 text-right hidden sm:block">{r.avg}</p>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 prog-track" style={{height:"5px"}}>
                      <div className="prog-fill" style={{width:`${r.score}%`}}/>
                    </div>
                    <span className="mono text-xs font-extrabold text-blue-700 w-7 text-right">{r.score}</span>
                  </div>
                  <p className={`mono text-xs font-bold text-right ${r.up ? "text-emerald-600" : r.trend === "0%" ? "text-slate-400" : "text-red-500"}`}>
                    {r.trend}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Side panels */}
          <div className="flex flex-col gap-4">
            {/* Recent completions */}
            <div className="card shadow-card overflow-hidden">
              <div className="px-5 py-4 border-b border-slate-100 flex items-center gap-2">
                <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"/>
                <p className="font-extrabold text-slate-900 text-sm">Recent Completions</p>
              </div>
              <div className="divide-y divide-slate-50">
                {RECENT_DONE.map(r => (
                  <div key={r.id} className="px-5 py-3.5 hover:bg-slate-50 transition-colors">
                    <div className="flex justify-between items-center mb-0.5">
                      <span className="mono text-[10px] text-blue-700 font-bold">{r.id}</span>
                      <span className="mono text-[10px] text-slate-400">{r.date}</span>
                    </div>
                    <p className="text-xs font-bold text-slate-800 mb-1.5 truncate">{r.loc}</p>
                    <div className="flex items-center justify-between">
                      <span className="body-text text-[10px] text-slate-400">{r.days}d to repair</span>
                      <div className="flex items-center gap-0.5">
                        {[1,2,3,4,5].map(n => (
                          <I.Star key={n} s={10} c={n <= Math.round(r.stars)?"text-amber-400":"text-slate-200"} filled/>
                        ))}
                        <span className="mono text-[9px] text-slate-500 ml-1">{r.stars}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* RoadScore card */}
            <div className="grad-navy rounded-[20px] p-5 text-white">
              <div className="w-11 h-11 bg-white/10 rounded-2xl flex items-center justify-center mb-4">
                <I.Award s={22} c="text-white"/>
              </div>
              <p className="font-extrabold text-lg mb-2">RoadScore™</p>
              <p className="body-text text-white/65 text-sm leading-relaxed mb-4">
                Our composite accountability metric combines resolution time, citizen satisfaction, SLA adherence, and repair recurrence into a single public score.
              </p>
              <div className="space-y-2">
                {[
                  {l:"Resolution Speed", w:"72%"},
                  {l:"Citizen Rating", w:"88%"},
                  {l:"SLA Adherence", w:"65%"},
                ].map(m => (
                  <div key={m.l}>
                    <div className="flex justify-between mb-1">
                      <span className="text-white/60 text-[10px] font-medium">{m.l}</span>
                      <span className="mono text-[10px] text-white font-bold">{m.w}</span>
                    </div>
                    <div className="prog-track" style={{background:"rgba(255,255,255,0.1)"}}>
                      <div className="prog-fill" style={{width:m.w, background:"linear-gradient(90deg,#60a5fa,#34d399)"}}/>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ─────────────────────────────────────────────────────────
   FINAL CTA
───────────────────────────────────────────────────────── */
function FinalCTA({ onReport }: { onReport: () => void }) {
  const ref = useReveal();
  return (
    <section className="py-28 relative overflow-hidden">
      <div className="absolute inset-0 bg-slate-950">
        <img src="https://images.unsplash.com/photo-1520594923568-1b5d82587f86?w=1600&h=700&fit=crop&auto=format"
          alt="Indian road aerial" className="w-full h-full object-cover opacity-25 mix-blend-luminosity"/>
        <div className="absolute inset-0" style={{background:"linear-gradient(160deg,rgba(8,16,42,0.97) 0%,rgba(19,56,168,0.88) 55%,rgba(5,120,87,0.7) 100%)"}}/>
        <div className="absolute inset-0 opacity-[0.05]"
          style={{backgroundImage:"radial-gradient(circle,rgba(255,255,255,0.9) 1px,transparent 1px)",backgroundSize:"40px 40px"}}/>
      </div>

      <div ref={ref} className="reveal relative max-w-4xl mx-auto px-4 sm:px-6 text-center">
        <div className="inline-flex items-center gap-2.5 glass-white-sm rounded-full px-5 py-2.5 mb-10">
          <I.Users s={14} c="text-emerald-400"/>
          <span className="text-white/80 text-xs font-semibold">2,47,318 citizens already reporting</span>
        </div>
        <h2 className="text-5xl sm:text-6xl lg:text-7xl font-extrabold text-white leading-[1.04] tracking-[-0.02em] mb-6">
          Every road begins<br/>
          <span style={{background:"linear-gradient(90deg,#34d399,#059669)", WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent"}}>
            with one report.
          </span>
        </h2>
        <p className="body-text text-white/60 text-xl mb-12 max-w-xl mx-auto">
          Your photo triggers a chain of government accountability. Don't wait for someone else to act.
        </p>
        <div className="flex flex-wrap justify-center gap-4 mb-10">
          <button onClick={onReport} className="btn btn-blue btn-lg" style={{fontSize:"16px",padding:"18px 36px"}}>
            <I.Camera s={20}/> Report a Pothole Now
          </button>
          <button className="btn btn-ghost btn-lg" style={{fontSize:"16px",padding:"18px 36px"}}>
            Download the App
          </button>
        </div>

        {/* App badges */}
        <div className="flex flex-wrap justify-center gap-3">
          {[
            {icon:"📱", sub:"Download on the", main:"App Store"},
            {icon:"▶️", sub:"Get it on", main:"Google Play"},
            {icon:"🌐", sub:"Access via", main:"Web Browser"},
          ].map(b => (
            <div key={b.main} className="glass-white-sm rounded-2xl px-5 py-3.5 flex items-center gap-3.5 cursor-pointer hover:bg-white/20 transition-all">
              <span className="text-2xl">{b.icon}</span>
              <div className="text-left">
                <p className="text-white/50 text-[9px]">{b.sub}</p>
                <p className="text-white font-bold text-sm">{b.main}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─────────────────────────────────────────────────────────
   FOOTER
───────────────────────────────────────────────────────── */
function Footer() {
  const cols = [
    {head:"Platform", links:["Report a Pothole","Track Complaint","Live Map","Community Dashboard","Mobile App"]},
    {head:"Government", links:["Municipal Partner Portal","API Documentation","SLA Guidelines","RTI Portal","Grievance Redressal"]},
    {head:"Support", links:["About RoadRakshak","Privacy Policy","Terms of Service","Contact Us","Press Kit"]},
  ];

  return (
    <footer className="grad-navy text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-8">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2.5 mb-4">
              <div className="w-8 h-8 grad-blue rounded-[10px] flex items-center justify-center">
                <I.Pin s={15} c="text-white"/>
              </div>
              <span className="font-extrabold text-lg">Road<span className="text-emerald-400">Rakshak</span></span>
            </div>
            <p className="body-text text-white/45 text-sm leading-relaxed mb-5">
              An initiative by the Ministry of Road Transport & Highways, Government of India. Safer roads for 1.4 billion citizens.
            </p>
            <div className="flag-bar w-20 mb-5 rounded overflow-hidden" style={{height:"5px"}}>
              <div/><div/><div/>
            </div>
            <div className="flex flex-wrap gap-2">
              {["ISO 27001","CERT-In","DigiLocker","MeitY"].map(b => (
                <span key={b} className="mono text-[9px] border border-white/15 text-white/40 px-2 py-1 rounded-lg">{b}</span>
              ))}
            </div>
          </div>

          {cols.map(col => (
            <div key={col.head}>
              <p className="font-bold text-white/80 mb-4 text-sm">{col.head}</p>
              <ul className="space-y-3">
                {col.links.map(l => (
                  <li key={l}>
                    <a href="#" className="body-text text-white/40 hover:text-white text-sm transition-colors">{l}</a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="border-t border-white/8 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="body-text text-white/30 text-xs text-center sm:text-left">
            © 2024 Ministry of Road Transport & Highways, Government of India · All rights reserved
          </p>
          <div className="flex items-center gap-4">
            <span className="text-white/30 text-xs body-text">Made with ❤️ in India</span>
            <span className="text-white/15">·</span>
            <span className="mono text-white/25 text-[10px]">v2.4.1</span>
          </div>
        </div>
      </div>
    </footer>
  );
}

/* ─────────────────────────────────────────────────────────
   FLOATING ACTION BUTTON
───────────────────────────────────────────────────────── */
function FAB({ onClick }: { onClick: () => void }) {
  const [show, setShow] = useState(false);
  useEffect(() => {
    const fn = () => setShow(window.scrollY > 500);
    window.addEventListener("scroll", fn, { passive: true });
    return () => window.removeEventListener("scroll", fn);
  }, []);

  return (
    <button onClick={onClick} className={`fab transition-all duration-300 ${show ? "fab-visible" : "fab-hidden"}`}>
      <I.Camera s={16}/> Report Now
    </button>
  );
}

/* ─────────────────────────────────────────────────────────
   ROOT APP
───────────────────────────────────────────────────────── */
export default function App() {
  const scrollToReport = () => document.getElementById("report")?.scrollIntoView({ behavior: "smooth" });
  const scrollToTrack  = () => document.getElementById("track")?.scrollIntoView({ behavior: "smooth" });

  return (
    <div className="min-h-full bg-white">
      <Nav onReport={scrollToReport}/>
      <Hero onReport={scrollToReport} onTrack={scrollToTrack}/>
      <LiveImpact/>
      <HowItWorks/>
      <InteractiveMap/>
      <ReportInterface/>
      <TrackDashboard/>
      <Features/>
      <Accountability/>
      <FinalCTA onReport={scrollToReport}/>
      <Footer/>
      <FAB onClick={scrollToReport}/>
    </div>
  );
}
